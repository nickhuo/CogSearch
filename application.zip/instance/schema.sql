
DROP TABLE IF EXISTS tb1_user;

CREATE TABLE tb1_user (
    uid INTEGER PRIMARY KEY AUTOINCREMENT,
    sid INTEGER NOT NULL,
    mturk_id TEXT NOT NULL,
    consent_time DATETIME NOT NULL,
    taskDone INTEGER DEFAULT 0,
    conDone INTEGER DEFAULT 0,
    topIDorder TEXT,
    conIDorder TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
